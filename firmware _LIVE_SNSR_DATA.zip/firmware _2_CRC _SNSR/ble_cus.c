#include "sdk_common.h"
#include "ble_cus.h"
#include "ble_cus 2.h"
#include <string.h>
#include "ble_srv_common.h"
#include "nrf_gpio.h"
#include "boards.h"
#include "nrf_log.h"
#include "ble_cus.h"
#include "ble_gattc.h"
#include "ble_gatts.h"


static ble_gatts_char_handles_t char1_handle;

static ble_gatts_char_handles_t char2_handle;

static ble_gatts_char_handles_t char3_handle;

/**@brief Function for handling the Connect event.
 *
 * @param[in]   p_cus       Custom Service structure.
 * @param[in]   p_ble_evt   Event received from the BLE stack.
 */



static void on_connect(ble_cus_t * p_cus, ble_evt_t const * p_ble_evt)
{
NRF_LOG_INFO("INSIDE ON_CONN");
    p_cus->conn_handle = p_ble_evt->evt.gap_evt.conn_handle;

    ble_cus_evt_t evt;

    evt.evt_type = BLE_CUS_EVT_CONNECTED;

    p_cus->evt_handler(p_cus, &evt);
}

/**@brief Function for handling the Disconnect event.
 *
 * @param[in]   p_cus       Custom Service structure.
 * @param[in]   p_ble_evt   Event received from the BLE stack.
 */
static void on_disconnect(ble_cus_t * p_cus, ble_evt_t const * p_ble_evt)
{
  NRF_LOG_INFO("INSIDE ON_DISCON");
    UNUSED_PARAMETER(p_ble_evt);
    p_cus->conn_handle = BLE_CONN_HANDLE_INVALID;
    
    ble_cus_evt_t evt;

    evt.evt_type = BLE_CUS_EVT_DISCONNECTED;

    p_cus->evt_handler(p_cus, &evt);
}

/**@brief Function for handling the Write event.
 *
 * @param[in]   p_cus       Custom Service structure.
 * @param[in]   p_ble_evt   Event received from the BLE stack.
 */
static void on_write(ble_cus_t * p_cus, ble_evt_t const * p_ble_evt)//cus write evt
{
    ble_gatts_evt_write_t const * p_evt_write = &p_ble_evt->evt.gatts_evt.params.write;
    NRF_LOG_INFO("INSIDE ON_WRITE");
     ble_cus_evt_t evt;
    // Custom Value Characteristic Written to.
     NRF_LOG_INFO("GATTS cus DATA uuid %x",p_ble_evt->evt.gatts_evt.params.write.uuid.uuid);
              NRF_LOG_INFO("GATTS cus DATA length %x",p_ble_evt->evt.gatts_evt.params.write.len);
              NRF_LOG_INFO("GATTS cus DATA0  %x",p_ble_evt->evt.gatts_evt.params.write.data[0]);
              NRF_LOG_INFO("GATTS cus DATA1  %x",p_ble_evt->evt.gatts_evt.params.write.data[1]);
              NRF_LOG_INFO("GATTS cus DATA2  %x",p_ble_evt->evt.gatts_evt.params.write.data[2]);
              NRF_LOG_INFO("GATTS cus DATA3  %x",p_ble_evt->evt.gatts_evt.params.write.data[3]);
              NRF_LOG_INFO("GATTS cus DATA4  %x",p_ble_evt->evt.gatts_evt.params.write.data[4]);
              NRF_LOG_INFO("GATTS cus DATA4  %x",p_ble_evt->evt.gatts_evt.params.write.data[5]);
              NRF_LOG_INFO("GATTS cus DATA4  %x",p_ble_evt->evt.gatts_evt.params.write.data[6]);

          if(p_ble_evt->evt.gatts_evt.params.write.uuid.uuid == 0x6510)
          {
              if(p_ble_evt->evt.gatts_evt.params.write.data[0] == 0xBE)
              {

                  if(p_ble_evt->evt.gatts_evt.params.write.data[1] == 0x05)
                  {
                              if(p_ble_evt->evt.gatts_evt.params.write.data[2] == 0x48)//hanshake and ack packets
                              {
                                  evt.evt_type = BLE_CUS_EVT_HANSHAKE_ACK;
                                   p_cus->evt_handler(p_cus, &evt);
                                   NRF_LOG_INFO("AFTER HANDSHAKE IN CUS");
                                   evt.evt_type = BLE_CUS_EVT_HEALTH_PACKET;
                                   p_cus->evt_handler(p_cus, &evt);

                              }

                              if(p_ble_evt->evt.gatts_evt.params.write.data[2] == 0x01 )//SCAN SOIL PACKETS
                              {     
                                         if(p_ble_evt->evt.gatts_evt.params.write.data[3] == 0xFF)//ALL
                                         {
                                            evt.evt_type = BLE_CUS_EVT_SCAN_SOIL_ALL;
                                            p_cus->evt_handler(p_cus, &evt);
                                         }

                                         if(p_ble_evt->evt.gatts_evt.params.write.data[3] == 0x01)//PH
                                         {
                                            evt.evt_type = BLE_CUS_EVT_SCAN_SOIL_PH_ONLY;
                                            p_cus->evt_handler(p_cus, &evt);
                                         }

                                         if(p_ble_evt->evt.gatts_evt.params.write.data[3] == 0x02)//EC
                                         {
                                            evt.evt_type = BLE_CUS_EVT_SCAN_SOIL_EC_ONLY;
                                            p_cus->evt_handler(p_cus, &evt);
                                         }

                                         if(p_ble_evt->evt.gatts_evt.params.write.data[3] == 0x04)//TEMP
                                         {
                                            evt.evt_type = BLE_CUS_EVT_SCAN_SOIL_TEMP_ONLY;
                                            p_cus->evt_handler(p_cus, &evt);
                                         }

                                         if(p_ble_evt->evt.gatts_evt.params.write.data[3] == 0x08)//MOISTURE
                                         {
                                            evt.evt_type = BLE_CUS_EVT_SCAN_SOIL_MOISTURE_ONLY;
                                            p_cus->evt_handler(p_cus, &evt);
                                         }

                                         if(p_ble_evt->evt.gatts_evt.params.write.data[3] == 0x10)//NITROGEN
                                         {
                                            evt.evt_type = BLE_CUS_EVT_SCAN_SOIL_NITRO_ONLY;
                                            p_cus->evt_handler(p_cus, &evt);
                                         }

                                            if(p_ble_evt->evt.gatts_evt.params.write.data[3] == 0x20)//PHOSPHORUS
                                         {
                                            evt.evt_type = BLE_CUS_EVT_SCAN_SOIL_PHOSP_ONLY;
                                            p_cus->evt_handler(p_cus, &evt);
                                         }

                                            if(p_ble_evt->evt.gatts_evt.params.write.data[3] == 0x40)//POTASSIUM
                                         {
                                            evt.evt_type = BLE_CUS_EVT_SCAN_SOIL_POTASSIUM_ONLY;
                                            p_cus->evt_handler(p_cus, &evt);
                                         }

                                            if(p_ble_evt->evt.gatts_evt.params.write.data[3] == 0x80)//HUMIDITY
                                         {
                                            evt.evt_type = BLE_CUS_EVT_SCAN_SOIL_HUMIDITY_ONLY;
                                            p_cus->evt_handler(p_cus, &evt);
                                         }
                              }

                           if(p_ble_evt->evt.gatts_evt.params.write.data[2] == 0x02 )//SCAN WATER PACKET
                            {
                                      if(p_ble_evt->evt.gatts_evt.params.write.data[3] == 0x07)//ALL
                                   {
                                      evt.evt_type = BLE_CUS_EVT_SCAN_WATER_ALL;
                                      p_cus->evt_handler(p_cus, &evt);
                                   }

                                   if(p_ble_evt->evt.gatts_evt.params.write.data[3] == 0x01)//PH
                                   {
                                      evt.evt_type = BLE_CUS_EVT_SCAN_WATER_PH_ONLY;
                                      p_cus->evt_handler(p_cus, &evt);
                                   }

                                   if(p_ble_evt->evt.gatts_evt.params.write.data[3] == 0x02)//EC
                                   {
                                      evt.evt_type = BLE_CUS_EVT_SCAN_WATER_EC_ONLY;
                                      p_cus->evt_handler(p_cus, &evt);
                                   }

                                   if(p_ble_evt->evt.gatts_evt.params.write.data[3] == 0x03)//PH AND EC
                                   {
                                      evt.evt_type = BLE_CUS_EVT_SCAN_WATER_PH_AND_EC_ONLY;
                                      p_cus->evt_handler(p_cus, &evt);
                                   }
                           
                                   if(p_ble_evt->evt.gatts_evt.params.write.data[3] == 0x04)// TDS
                                   {
                                      evt.evt_type = BLE_CUS_EVT_SCAN_WATER_TDS_ONLY;
                                      p_cus->evt_handler(p_cus, &evt);
                                   }
                            }

                          if( p_ble_evt->evt.gatts_evt.params.write.data[2] == 0x03 && p_ble_evt->evt.gatts_evt.params.write.data[3] == 0xFF)//scan all
                          {
                               evt.evt_type = BLE_CUS_EVT_SCAN_ALL;
                             p_cus->evt_handler(p_cus, &evt);
                          }

                          if(p_ble_evt->evt.gatts_evt.params.write.data[2] == 0xD0)
                          {
                                evt.evt_type = BLE_CUS_EVT_SOIL_PH_CALIBRATION;
                                p_cus->evt_handler(p_cus, &evt);
                          }

                          if(p_ble_evt->evt.gatts_evt.params.write.data[2] == 0xD1)
                          {
                                evt.evt_type = BLE_CUS_EVT_SOIL_EC_CALIBRATION;
                                p_cus->evt_handler(p_cus, &evt);
                          }

                          if(p_ble_evt->evt.gatts_evt.params.write.data[2] == 0xD2)
                          {
                                evt.evt_type = BLE_CUS_EVT_TEMP_CALIBRATION;
                                p_cus->evt_handler(p_cus, &evt);
                          }

                          if(p_ble_evt->evt.gatts_evt.params.write.data[2] == 0xD3)
                          {
                                evt.evt_type = BLE_CUS_EVT_HUMIDITY_CALIBRATION;
                                p_cus->evt_handler(p_cus, &evt);
                          }

                          if(p_ble_evt->evt.gatts_evt.params.write.data[2] == 0xD4)
                          {
                                evt.evt_type = BLE_CUS_EVT_MOISTURE_CALIBRATION;
                                p_cus->evt_handler(p_cus, &evt);
                          }

                          if(p_ble_evt->evt.gatts_evt.params.write.data[2] == 0xD5)
                          {
                                evt.evt_type = BLE_CUS_EVT_NITROGEN_CALIBRATION;
                                p_cus->evt_handler(p_cus, &evt);
                          }

                          if(p_ble_evt->evt.gatts_evt.params.write.data[2] == 0xD6)
                          {
                                evt.evt_type = BLE_CUS_EVT_PHOSPHOROUS_CALIBRATION;
                                p_cus->evt_handler(p_cus, &evt);
                          }

                          if(p_ble_evt->evt.gatts_evt.params.write.data[2] == 0xD7)
                          {
                                evt.evt_type = BLE_CUS_EVT_POTASSIUM_CALIBRATION;
                                p_cus->evt_handler(p_cus, &evt);
                          }

                          if(p_ble_evt->evt.gatts_evt.params.write.data[2] == 0xD8)
                          {
                                evt.evt_type = BLE_CUS_EVT_WATER_PH_CALIBRATION;
                                p_cus->evt_handler(p_cus, &evt);
                          }

                          if(p_ble_evt->evt.gatts_evt.params.write.data[2] == 0xD9)
                          {
                                evt.evt_type = BLE_CUS_EVT_WATER_EC_CALIBRATION;
                                p_cus->evt_handler(p_cus, &evt);
                          }

                          if(p_ble_evt->evt.gatts_evt.params.write.data[2] == 0xDA)
                          {
                                evt.evt_type = BLE_CUS_EVT_WATER_TDS_CALIBRATION;
                                p_cus->evt_handler(p_cus, &evt);
                          }
                  }
             }

          }
    if (p_evt_write->handle == char1_handle.value_handle)
    {
    NRF_LOG_INFO("INSIDE char1 handle if1 %d",p_evt_write->handle);
    NRF_LOG_INFO("data1 %d",*p_evt_write->data);
        nrf_gpio_pin_toggle(LED_4);
        ble_cus_evt_t evt;
        if(*p_evt_write->data == 0xBE)
        {
            nrf_gpio_pin_toggle(20);
            //evt.evt_type = BLE_CUS_EVT_HANSHAKE_ACK; 
        }
        //else if(*p_evt_write->data == 0x02)
        //{
        //    nrf_gpio_pin_set(20); 
        //}
        else
        {
          //Do nothing
        }
        p_cus->evt_handler(p_cus, &evt);
    }

    // Check if the Custom value CCCD is written to and that the value is the appropriate length, i.e 2 bytes.
    if ((p_evt_write->handle == char1_handle.cccd_handle)
        && (p_evt_write->len == 9)
       )
    {
    NRF_LOG_INFO("INSIDE char1 cccd handle if2 %d",p_evt_write->handle);
        // CCCD written, call application event handler
        if (p_cus->evt_handler != NULL)
        {
            ble_cus_evt_t evt;
            NRF_LOG_INFO("DATA1 %d",*p_evt_write->data);
            if (ble_srv_is_notification_enabled(p_evt_write->data))
            {
                //evt.evt_type = BLE_CUS_EVT_NOTIFICATION_ENABLED1;
                NRF_LOG_INFO("1ST ENABLED");
            }
            else
            {
                evt.evt_type = BLE_CUS_EVT_NOTIFICATION_DISABLED1;
                NRF_LOG_INFO("1ST DISABLED");
            }
            // Call the application event handler.
            p_cus->evt_handler(p_cus, &evt);
        }
    }

      if (p_evt_write->handle == char2_handle.value_handle)
    {
    NRF_LOG_INFO("INSIDE char2 handle if1 %d",p_evt_write->handle);
    NRF_LOG_INFO("if1 data2 %d",*p_evt_write->data);
        nrf_gpio_pin_toggle(LED_3);
        /*
        if(*p_evt_write->data == 0x01)
        {
            nrf_gpio_pin_clear(20); 
        }
        else if(*p_evt_write->data == 0x02)
        {
            nrf_gpio_pin_set(20); 
        }
        else
        {
          //Do nothing
        }
        */
    }

    // Check if the Custom value CCCD is written to and that the value is the appropriate length, i.e 2 bytes.
    if ((p_evt_write->handle == char2_handle.cccd_handle)
        && (p_evt_write->len == 9)
       )
    {
    NRF_LOG_INFO("INSIDE char2 cccd handle if2 %d",p_evt_write->handle);
        // CCCD written, call application event handler
        if (p_cus->evt_handler != NULL)
        {
            ble_cus_evt_t evt;
             NRF_LOG_INFO("DATA2 %d",*p_evt_write->data);
            if (ble_srv_is_notification_enabled(p_evt_write->data))
            {
                evt.evt_type = BLE_CUS_EVT_NOTIFICATION_ENABLED2;
                NRF_LOG_INFO("1ST ENABLED");
            }
            else
            {
                evt.evt_type = BLE_CUS_EVT_NOTIFICATION_DISABLED2;
                NRF_LOG_INFO("1ST DISABLED");
            }
            // Call the application event handler.
            p_cus->evt_handler(p_cus, &evt);
        }
    }
}

void ble_cus_on_ble_evt( ble_evt_t const * p_ble_evt, void * p_context)
{
    ble_cus_t * p_cus = (ble_cus_t *) p_context;
    
    NRF_LOG_INFO("BLE event received. Event type = %d\r\n", p_ble_evt->header.evt_id); 
    if (p_cus == NULL || p_ble_evt == NULL)
    {
        return;
    }
    
    switch (p_ble_evt->header.evt_id)
    {
        case BLE_GAP_EVT_CONNECTED:
            on_connect(p_cus, p_ble_evt);
            break;

        case BLE_GAP_EVT_DISCONNECTED:
            on_disconnect(p_cus, p_ble_evt);
            break;

        case BLE_GATTS_EVT_WRITE:
        NRF_LOG_INFO("IN cus BLE CUS EVT-WRITE");
            on_write(p_cus, p_ble_evt);
            break;
//Handling this event is not necessary
        case BLE_GATTS_EVT_EXCHANGE_MTU_REQUEST:
            NRF_LOG_INFO("EXCHANGE_MTU_REQUEST event received.\r\n");
            NRF_LOG_INFO("exchange data %x",p_ble_evt->evt.gatts_evt.params.write.data);
            break;

        case BLE_GATTC_EVT_HVX:
        NRF_LOG_INFO("INSIDE GATTC HVX MAIN");
        break;

      case BLE_GATTS_EVT_RW_AUTHORIZE_REQUEST:
      NRF_LOG_INFO("INSIDE RW DATA %x",p_ble_evt->evt.gatts_evt.params.write.data);
      NRF_LOG_INFO("INSIDE RW DATA %x",p_ble_evt->evt.gatts_evt.params.authorize_request.request.write.data);
            NRF_LOG_INFO("INSIDE RW AUTH RQST");
            break;

      case BLE_GATTC_EVT_WRITE_RSP:
      NRF_LOG_INFO("INSIDE GATTC WRITE RSP CUS");
      break;

      case BLE_GATTC_EVT_CHAR_VAL_BY_UUID_READ_RSP:
      NRF_LOG_INFO("INSIDE CHAR VAL BY UUID");
      break;
        default:
            // No implementation needed.
            break;
    }
}

/**@brief Function for adding the Custom Value characteristic.
 *
 * @param[in]   p_cus        Battery Service structure.
 * @param[in]   p_cus_init   Information needed to initialize the service.
 *
 * @return      NRF_SUCCESS on success, otherwise an error code.
 */
static uint32_t custom_value_char_add(ble_cus_t * p_cus, const ble_cus_init_t * p_cus_init)
{

    uint8_t             val1 = 20;
    uint8_t             val2 = 30;
    uint8_t             val3 = 40;
    uint32_t            err_code;
    ble_gatts_char_md_t char_md1;
    ble_gatts_attr_md_t cccd_md1;
    ble_gatts_attr_t    attr_char_value1;
    ble_uuid_t          ble_uuid1;
    ble_gatts_attr_md_t attr_md1;

    // Add Custom Value characteristic
    memset(&cccd_md1, 0, sizeof(cccd_md1));

    //  Read  operation on cccd should be possible without authentication.
    BLE_GAP_CONN_SEC_MODE_SET_OPEN(&cccd_md1.read_perm);
    BLE_GAP_CONN_SEC_MODE_SET_OPEN(&cccd_md1.write_perm);
    
    cccd_md1.write_perm = p_cus_init->custom_value_char_attr_md.cccd_write_perm;
    cccd_md1.vloc       = BLE_GATTS_VLOC_STACK;

    memset(&char_md1, 0, sizeof(char_md1));

    char_md1.char_props.read   = 1;
    char_md1.char_props.write  = 1;
    char_md1.char_props.notify = 1; 
    char_md1.p_char_user_desc  = NULL;
    char_md1.p_char_pf         = NULL;
    char_md1.p_user_desc_md    = NULL;
    char_md1.p_cccd_md         = &cccd_md1; 
    char_md1.p_sccd_md         = NULL;

    //Adding char UUID

    ble_uuid128_t char1_base_uuid = {CUSTOM_VALUE_CHAR1_UUID_BASE};
        err_code =  sd_ble_uuid_vs_add(&char1_base_uuid, &p_cus->uuid_type);
    VERIFY_SUCCESS(err_code);
		
    ble_uuid1.type = p_cus->uuid_type;
    ble_uuid1.uuid = CUSTOM_VALUE_CHAR1_UUID;

    memset(&attr_md1, 0, sizeof(attr_md1));

    attr_md1.read_perm  = p_cus_init->custom_value_char_attr_md.read_perm;
    attr_md1.write_perm = p_cus_init->custom_value_char_attr_md.write_perm;
    attr_md1.vloc       = BLE_GATTS_VLOC_STACK;
    attr_md1.rd_auth    = 0;
    attr_md1.wr_auth    = 0;
    attr_md1.vlen       = 0;

    memset(&attr_char_value1, 0, sizeof(attr_char_value1));

    attr_char_value1.p_uuid    = &ble_uuid1;
    attr_char_value1.p_attr_md = &attr_md1;
    attr_char_value1.init_len  = sizeof(uint8_t);
    attr_char_value1.init_offs = 0;
    attr_char_value1.max_len   = 40*sizeof(uint8_t);//attribute size selection
    attr_char_value1.p_value   = &val1;

    err_code = sd_ble_gatts_characteristic_add(p_cus->service_handle, &char_md1,
                                               &attr_char_value1,
                                               &char1_handle);
    if (err_code != NRF_SUCCESS)
    {
        return err_code;
    }

  NRF_LOG_INFO("CHAR1_HANDLE %d",char1_handle.value_handle);
  NRF_LOG_INFO("CHAR1_cccd_HANDLE %d",char1_handle.cccd_handle);


    
    ble_gatts_char_md_t char_md2;
    ble_gatts_attr_md_t cccd_md2;
    ble_gatts_attr_t    attr_char_value2;
    ble_uuid_t          ble_uuid2;
    ble_gatts_attr_md_t attr_md2;

    // Add Custom Value characteristic
    memset(&cccd_md2, 0, sizeof(cccd_md2));

    //  Read  operation on cccd should be possible without authentication.
    BLE_GAP_CONN_SEC_MODE_SET_OPEN(&cccd_md2.read_perm);
    BLE_GAP_CONN_SEC_MODE_SET_OPEN(&cccd_md2.write_perm);
    
    cccd_md2.write_perm = p_cus_init->custom_value_char_attr_md.cccd_write_perm;
    cccd_md2.vloc       = BLE_GATTS_VLOC_STACK;

    memset(&char_md2, 0, sizeof(char_md2));

    char_md2.char_props.read   = 1;
    char_md2.char_props.write  = 1;
    char_md2.char_props.notify = 0; 
    char_md2.p_char_user_desc  = NULL;
    char_md2.p_char_pf         = NULL;
    char_md2.p_user_desc_md    = NULL;
    char_md2.p_cccd_md         = &cccd_md2; 
    char_md2.p_sccd_md         = NULL;

        ble_uuid128_t char2_base_uuid = {CUSTOM_VALUE_CHAR2_UUID_BASE};
        err_code =  sd_ble_uuid_vs_add(&char2_base_uuid, &p_cus->uuid_type);
    VERIFY_SUCCESS(err_code);
		
    ble_uuid2.type = p_cus->uuid_type;
    ble_uuid2.uuid = CUSTOM_VALUE_CHAR2_UUID;

    memset(&attr_md2, 0, sizeof(attr_md2));

    attr_md2.read_perm  = p_cus_init->custom_value_char_attr_md.read_perm;
    attr_md2.write_perm = p_cus_init->custom_value_char_attr_md.write_perm;
    attr_md2.vloc       = BLE_GATTS_VLOC_STACK;
    attr_md2.rd_auth    = 0;
    attr_md2.wr_auth    = 0;
    attr_md2.vlen       = 0;

    memset(&attr_char_value2, 0, sizeof(attr_char_value2));

    attr_char_value2.p_uuid    = &ble_uuid2;
    attr_char_value2.p_attr_md = &attr_md2;
    attr_char_value2.init_len  = sizeof(uint8_t);
    attr_char_value2.init_offs = 0;
    attr_char_value2.max_len   = 40*sizeof(uint8_t);//attribute size selection
    attr_char_value2.p_value   = &val2;

    err_code = sd_ble_gatts_characteristic_add(p_cus->service_handle, &char_md2,
                                               &attr_char_value2,
                                               &char2_handle);
    if (err_code != NRF_SUCCESS)
    {
        return err_code;
    }
    NRF_LOG_INFO("CHAR2_HANDLE %d",char2_handle.value_handle);
    NRF_LOG_INFO("CHAR2cccd_HANDLE %d",char2_handle.cccd_handle);


    
    return NRF_SUCCESS;
}

uint32_t ble_cus_init(ble_cus_t * p_cus, const ble_cus_init_t * p_cus_init)
{
    if (p_cus == NULL || p_cus_init == NULL)
    {
        return NRF_ERROR_NULL;
    }

    uint32_t   err_code;
    ble_uuid_t ble_uuid;

    // Initialize service structure
    p_cus->evt_handler               = p_cus_init->evt_handler;
    p_cus->conn_handle               = BLE_CONN_HANDLE_INVALID;

    // Add Custom Service UUID
    ble_uuid128_t base_uuid = {CUSTOM_SERVICE_UUID_BASE};
    err_code =  sd_ble_uuid_vs_add(&base_uuid, &p_cus->uuid_type);
    VERIFY_SUCCESS(err_code);
    
    ble_uuid.type = p_cus->uuid_type;
    ble_uuid.uuid = CUSTOM_SERVICE_UUID;

    // Add the Custom Service
    err_code = sd_ble_gatts_service_add(BLE_GATTS_SRVC_TYPE_PRIMARY, &ble_uuid, &p_cus->service_handle);
    if (err_code != NRF_SUCCESS)
    {
        return err_code;
    }

    // Add Custom Value characteristic
    return custom_value_char_add(p_cus, p_cus_init);
}

uint32_t ble_cus_custom_value_update(ble_cus_t * p_cus, uint8_t * custom_value)
{
    NRF_LOG_INFO("In ble_cus_custom_value_update. \r\n"); 
    if (p_cus == NULL)
    {
        return NRF_ERROR_NULL;
    }

    uint32_t err_code = NRF_SUCCESS;
    ble_gatts_value_t gatts_value;

    // Initialize value struct.
    memset(&gatts_value, 0, sizeof(gatts_value));

    gatts_value.len     = 40*sizeof(uint8_t);
    gatts_value.offset  = 0;
    gatts_value.p_value = custom_value;

    // Update database.
    err_code = sd_ble_gatts_value_set(p_cus->conn_handle,
                                      char1_handle.value_handle,
                                      &gatts_value);//Set the value of a given attribute.


    if (err_code != NRF_SUCCESS)
    {
        return err_code;
    }

    // Send value if connected and notifying.
    if ((p_cus->conn_handle != BLE_CONN_HANDLE_INVALID)) 
    {
        ble_gatts_hvx_params_t hvx_params;

        memset(&hvx_params, 0, sizeof(hvx_params));

        hvx_params.handle = char1_handle.value_handle;
        hvx_params.type   = BLE_GATT_HVX_NOTIFICATION;
        hvx_params.offset = gatts_value.offset;
        hvx_params.p_len  = &gatts_value.len;
        hvx_params.p_data = gatts_value.p_value;

        err_code = sd_ble_gatts_hvx(p_cus->conn_handle, &hvx_params);
        NRF_LOG_INFO("sd_ble_gatts_hvx result: %x. \r\n", err_code); 
    }
    else
    {
        err_code = NRF_ERROR_INVALID_STATE;
        NRF_LOG_INFO("sd_ble_gatts_hvx result: NRF_ERROR_INVALID_STATE. \r\n"); 
    }


    return err_code;
}

uint32_t ble_cus_custom_value_update2(ble_cus_t * p_cus, uint8_t * custom_value)
{
    NRF_LOG_INFO("In ble_cus_custom_value_update. \r\n");
    static uint8_t count = 0;
     if(count ==1)
     {
      return NRF_SUCCESS;
     }
    if (p_cus == NULL)
    {
        return NRF_ERROR_NULL;
    }

    uint32_t err_code = NRF_SUCCESS;
    ble_gatts_value_t gatts_value;

    // Initialize value struct.
    memset(&gatts_value, 0, sizeof(gatts_value));

    gatts_value.len     = 50*sizeof(uint8_t);
    gatts_value.offset  = 0;
    gatts_value.p_value = custom_value;

    // Update database.
    err_code = sd_ble_gatts_value_set(p_cus->conn_handle,
                                      char1_handle.value_handle,
                                      &gatts_value);//Set the value of a given attribute.


    if (err_code != NRF_SUCCESS)
    {
        return err_code;
    }

    // Send value if connected and notifying.
    if ((p_cus->conn_handle != BLE_CONN_HANDLE_INVALID)) 
    {
        ble_gatts_hvx_params_t hvx_params;

        memset(&hvx_params, 0, sizeof(hvx_params));

        hvx_params.handle = char1_handle.value_handle;
        hvx_params.type   = BLE_GATT_HVX_NOTIFICATION;
        hvx_params.offset = gatts_value.offset;
        hvx_params.p_len  = &gatts_value.len;
        hvx_params.p_data = gatts_value.p_value;

        err_code = sd_ble_gatts_hvx(p_cus->conn_handle, &hvx_params);
        NRF_LOG_INFO("sd_ble_gatts_hvx result: %x. \r\n", err_code); 
    }
    else
    {
        err_code = NRF_ERROR_INVALID_STATE;
        NRF_LOG_INFO("sd_ble_gatts_hvx result: NRF_ERROR_INVALID_STATE. \r\n"); 
    }

    count++;
    return err_code;
}



